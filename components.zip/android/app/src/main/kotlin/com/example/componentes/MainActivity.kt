package com.example.componentes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
